from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.http import require_POST
from notas.models import MealFood, Meal


@login_required
def mealfood_edit(request, pk):

    # ⭐ Cargamos meal y created_by en el mismo query
    mf = get_object_or_404(
        MealFood.objects.select_related("meal", "meal__created_by"),
        pk=pk,
        meal__created_by=request.user,
    )

    if request.method == "POST":
        quantity = request.POST.get("quantity")

        if not quantity:
            messages.error(request, "Quantity is required")
            return redirect("mealfood_edit", pk=mf.pk)

        mf.quantity = quantity
        mf.save()

        messages.success(request, "Food updated")

        return redirect("meal_edit", pk=mf.meal.pk)

    return render(
        request,
        "notas/meals/mealfood_edit.html",
        {
            "mf": mf,
            "meal": mf.meal,   # 👉 ya está cargado en memoria
        }
    )


@login_required
@require_POST
def mealfood_remove(request, pk):

    # ⭐ Igual: traer meal en la misma query
    mf = get_object_or_404(
        MealFood.objects.select_related("meal", "meal__created_by"),
        pk=pk,
        meal__created_by=request.user,
    )

    meal_id = mf.meal.id
    mf.delete()

    return redirect("meal_edit", pk=meal_id)


@login_required
@require_POST
def mealfood_update(request, meal_id, mealfood_id):

    # ⭐ Traemos meal junto a mealfood
    meal = get_object_or_404(Meal, id=meal_id)

    mealfood = get_object_or_404(
        MealFood.objects.select_related("meal"),
        id=mealfood_id,
        meal=meal,
    )

    try:
        quantity = float(request.POST.get("quantity", 0))
    except ValueError:
        quantity = 0

    if quantity <= 0:
        messages.error(request, "La cantidad debe ser mayor a 0.")
        return redirect("meal_edit", meal.id)

    mealfood.quantity = quantity
    mealfood.save()

    messages.success(request, "Alimento actualizado correctamente.")
    return redirect("meal_edit", meal.id)
