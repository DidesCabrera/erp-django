from django.shortcuts import render
from notas.models import Meal, DailyPlan
from notas.actions.meal_resolvers import resolve_meal_actions
from notas.actions.dailyplan_resolvers import resolve_dailyplan_actions
from notas.actions.constants import MEAL_CONTEXT_LIST, DAILYPLAN_CONTEXT_LIST


def explore_meals(request):
    meals = (
        Meal.objects
        .filter(is_public=True, is_draft=False)
        .select_related("created_by")
        .order_by("-created_at")
    )

    items = []
    for meal in meals:
        items.append({
            "meal": meal,
            "actions": resolve_meal_actions(
                meal,
                user=request.user if request.user.is_authenticated else None,
                context={
                    "name": MEAL_CONTEXT_LIST,
                },
            )
        })

    return render(
        request,
        "notas/explore/meals_list.html",
        {
            "items": items,
        },
    )


def explore_dailyplans(request):
    dailyplans = (
        DailyPlan.objects
        .filter(is_public=True, is_draft=False)
        .select_related("created_by")
        .order_by("-created_at")
    )

    items = []
    for dailyplan in dailyplans:
        items.append({
            "dailyplan": dailyplan,
            "actions": resolve_dailyplan_actions(
                dailyplan,
                user=request.user if request.user.is_authenticated else None,
                context=DAILYPLAN_CONTEXT_LIST,
            )

        })

    return render(
        request,
        "notas/explore/dailyplans_list.html",
        {
            "items": items,
        },
    )
