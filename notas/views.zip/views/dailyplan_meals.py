from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from django.urls import reverse
from notas.models import DailyPlanMeal
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from notas.actions.dailyplan_meal_resolvers import (
    resolve_dailyplan_meal_actions,
    DAILYPLAN_MEAL_CONTEXT_DETAIL,
)


@login_required
def dailyplan_meal_detail(request, pk):
    """
    Vista de detalle de un DailyPlanMeal (una meal dentro del plan).
    Necesitamos: meal, dailyplan y sus foods → optimizamos consultas.
    """

    dpm = get_object_or_404(
        DailyPlanMeal.objects
            .select_related("meal", "dailyplan")              # join simple
            .prefetch_related("meal__meal_food_set__food"),  # 👉 evita N+1 para macros
        pk=pk,
        dailyplan__created_by=request.user,
    )

    actions = resolve_dailyplan_meal_actions(
        dpm,
        request.user,
        context={"name": DAILYPLAN_MEAL_CONTEXT_DETAIL},
    )

    navigation = [
        {"label": "Daily Plans", "url": reverse("dailyplan_list")},
        {"label": dpm.dailyplan.name, "url": None},
        {"label": dpm.meal.name, "url": None},
    ]

    header = {
        "title": dpm.meal.name,
        "subtitle": f"{dpm.meal.total_kcal:.0f} kcal",
        "navigation": navigation,
        "actions": actions,
    }

    return render(
        request,
        "notas/dailyplan_meals/detail.html",
        {
            "dailyplan_meal": dpm,
            "meal": dpm.meal,
            "actions": actions,
            "header": header,
        }
    )


@login_required
def dailyplan_meal_edit(request, pk):
    """
    Editar hora / nota de una meal dentro del plan.
    No necesitamos cargar foods — así que no prefetch-eamos.
    """

    dpm = get_object_or_404(
        DailyPlanMeal,
        pk=pk,
        dailyplan__created_by=request.user,
    )

    if request.method == "POST":
        dpm.hour = request.POST.get("hour") or None
        dpm.note = request.POST.get("note") or None
        dpm.save()
        return redirect("dailyplan_edit", pk=dpm.dailyplan.id)

    return render(
        request,
        "notas/dailyplan_meals/edit.html",
        {"dpm": dpm}
    )
