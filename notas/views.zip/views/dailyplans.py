from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from django.urls import reverse
from notas.models import DailyPlan, DailyPlanMeal, Meal
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from notas.models import DailyPlan
from notas.services.capabilities import get_capabilities
from notas.routing.meal import meal_url
from notas.actions.dailyplan_resolvers import resolve_dailyplan_actions
from notas.actions.dailyplan_meal_resolvers import resolve_dailyplan_meal_actions, DAILYPLAN_MEAL_CONTEXT
from notas.actions.constants import (
    DAILYPLAN_CONTEXT_LIST, 
    DAILYPLAN_CONTEXT_DETAIL,
    DAILYPLAN_CONTEXT_EDIT
)
from django.db.models import Sum, F, ExpressionWrapper, FloatField
from notas.services.nutrition import (
    PROTEIN_KCAL_PER_GRAM,
    CARBS_KCAL_PER_GRAM,
    FAT_KCAL_PER_GRAM,
)
from notas.services.kpis import get_dailyplan_kpis
from notas.services.viewmodels_builder import build_dailyplan_item
from notas.viewmodels.dailyplan import DailyPlanViewModel


@login_required
def dailyplan_list(request):

    dailyplans = (
        DailyPlan.objects
        .filter(created_by=request.user, is_draft=False)
        .order_by("-created_at")
        .prefetch_related(
            "dailyplan_meals__meal__meal_food_set__food"
        )
        .annotate(
            total_kcal_sql=Sum(
                ExpressionWrapper(
                    (F("dailyplan_meals__meal__meal_food_set__quantity") / 100.0) * (
                        F("dailyplan_meals__meal__meal_food_set__food__protein") * PROTEIN_KCAL_PER_GRAM +
                        F("dailyplan_meals__meal__meal_food_set__food__carbs")   * CARBS_KCAL_PER_GRAM +
                        F("dailyplan_meals__meal__meal_food_set__food__fat")     * FAT_KCAL_PER_GRAM
                    ),
                    output_field=FloatField(),
                )
            )
        )
    )

    items = [build_dailyplan_item(dp, request.user, DAILYPLAN_CONTEXT_LIST) for dp in dailyplans]

    return render(
        request,
        "notas/dailyplans/list.html",
        {"items": items},
    )



@login_required
def dailyplan_detail(request, pk):

    dailyplan = get_object_or_404(
        DailyPlan.objects.select_related("created_by"),
        pk=pk,
        created_by=request.user,
    )

    vm = DailyPlanViewModel(
        dailyplan,
        request.user,
        DAILYPLAN_CONTEXT_DETAIL,
    )

    caps = get_capabilities(request.user)
    if not caps:
        return HttpResponseForbidden("Unauthorized")

    meals = Meal.objects.filter(is_draft=False).order_by("name")

    dailyplan_actions = resolve_dailyplan_actions(
        dailyplan,
        request.user,
        context={"name": DAILYPLAN_CONTEXT_DETAIL}
    )

    dp_item = {
        "obj": dailyplan,
        "actions": dailyplan_actions,
        "kpis": get_dailyplan_kpis(dailyplan, request.user),
    }

    dailyplan_meals = dailyplan.meals_with_foods()

    items = []
    for dpm in dailyplan_meals:
        items.append({
            "obj": dpm.meal,
            "dailyplan_meal": dpm,
            "url": meal_url(dpm.meal),
            "actions": resolve_dailyplan_meal_actions(
                dpm,
                request.user,
                context={"name": DAILYPLAN_MEAL_CONTEXT},
            ),
        })

    navigation = [
        {"label": "My Daily Plans", "url": reverse("dailyplan_list")},
        {"label": dailyplan.name, "url": None},
    ]

    header = {
        "title": dailyplan.name,
        "subtitle": f"{dailyplan.total_kcal:.0f} kcal",
        "navigation": navigation,
        "actions": dailyplan_actions,
    }

    return render(
        request,
        "notas/dailyplans/detail.html",
        {
            "dp_item": dp_item,
            "items": items,
            "dailyplan": dailyplan,
            "meals": meals,
            "dailyplan_meals": dailyplan_meals,
            "navigation": navigation,
            "header": header,
            "vm": vm
        },
    )


@login_required
def dailyplan_create(request):
    if request.method == "POST":
        name = request.POST.get("name")

        if not name:
            messages.error(request, "El nombre es obligatorio")
            return redirect("dailyplan_create")

        dailyplan = DailyPlan.objects.create(
            name=name,
            created_by=request.user
        )
        return redirect("dailyplan_builder", pk=dailyplan.pk)

    return render(request, "notas/dailyplans/create.html")


@login_required
def dailyplan_builder(request, pk):
    dailyplan = get_object_or_404(
        DailyPlan,
        pk=pk,
        created_by=request.user,
    )

    vm = DailyPlanViewModel(
        dailyplan,
        request.user,
        DAILYPLAN_CONTEXT_DETAIL,
    )

    if not dailyplan.is_draft:
        return redirect("dailyplan_detail", pk=pk)

    meals = Meal.objects.filter(
        is_draft=False
    ).order_by("name")

    dailyplan_meals = dailyplan.meals_with_foods()

    navigation = [
        {"label": "Daily Plans", "url": reverse("dailyplan_list")},
        {"label": dailyplan.name, "url": None},
    ]

    header = {
        "title": dailyplan.name,
        "subtitle": f"{dailyplan.total_kcal:.0f} kcal",
        "navigation": navigation,
    }

    return render(
        request,
        "notas/dailyplans/dpm_create.html",
        {
            "dailyplan": dailyplan,
            "meals": meals,
            "dailyplan_meals": dailyplan_meals,
            "header": header,
            "vm": vm
        }
    )


@login_required
def dailyplan_rename(request, pk):
    dailyplan = get_object_or_404(
        DailyPlan,
        pk=pk,
        created_by=request.user,
    )

    if not dailyplan.is_draft:
        return redirect("dailyplan_edit", pk=pk)

    if request.method == "POST":
        name = request.POST.get("name", "").strip()

        if not name:
            messages.error(request, "El nombre no puede estar vacío.")
            return redirect("dailyplan_rename", pk=pk)

        dailyplan.name = name
        dailyplan.save()

        messages.success(request, "Nombre actualizado.")
        return redirect("dailyplan_builder", pk=pk)

    return render(
        request,
        "notas/dailyplans/rename.html",
        {"dailyplan": dailyplan}
    )



@login_required
def dailyplan_edit(request, pk):
    dailyplan = get_object_or_404(DailyPlan,pk=pk)

    vm = DailyPlanViewModel(
        dailyplan,
        request.user,
        DAILYPLAN_CONTEXT_DETAIL,
    )

    meals = Meal.objects.filter(
        is_draft=False
    ).order_by("name")





    dailyplan_meals = dailyplan.meals_with_foods()

    caps = get_capabilities(request.user)

    if not caps or not caps.can_edit_own_content():
        return HttpResponseForbidden("You cannot edit this dailyplan")

    # --------------------------------------------------
    # NAVIGATION / HEADER
    # --------------------------------------------------

    navigation = [
        {"label": "Daily Plan","url": reverse("dailyplan_list")},
        {"label": dailyplan.name,"url": None},
    ]

    header = {
        "title": dailyplan.name,
        "subtitle": f"{dailyplan.total_kcal:.0f} kcal",
        "navigation": navigation,
        "actions": resolve_dailyplan_actions(
                dailyplan,
                request.user,
                context={
                    "name": DAILYPLAN_CONTEXT_EDIT
                },
            ),
    }
    return render(
        request,
        "notas/dailyplans/edit.html",
        {
            "dailyplan": dailyplan,
            "meals": meals,
            "header": header,
            "dailyplan_meals": dailyplan_meals,
            "vm": vm
        }
    )


@login_required
@require_POST
def fork_dailyplan(request, dailyplan_id):

    original = get_object_or_404(DailyPlan, id=dailyplan_id)

    if not original.is_forkable:
        return HttpResponseForbidden("No puedes forkear este daily plan")

    forked = DailyPlan.objects.create(
        name=f"{original.name} (fork)",
        created_by=request.user,
        original_author=(
            original.original_author
            if original.original_author
            else original.created_by
        ),
        forked_from=original,
        is_public=False,
        is_forkable=True,
        is_copiable=False,
        is_draft=False,
    )

    for dpm in original.dailyplan_meals.all():
        DailyPlanMeal.objects.create(
            dailyplan=forked,
            meal=dpm.meal,
            note=dpm.note,
            hour=dpm.hour,
            order=dpm.order
        )

    messages.success(request, "Daily plan forked successfully")
    return redirect("dailyplan_detail", pk=forked.pk)


@login_required
@require_POST
def copy_dailyplan(request, pk):

    dailyplan = get_object_or_404(DailyPlan, pk=pk)

    copy = DailyPlan.objects.create(
        name=f"{dailyplan.name} (copy)",
        created_by=request.user,
        is_public=False,
        is_forkable=True,
        is_copiable=False,
        is_draft=False,
    )

    for dpm in dailyplan.dailyplan_meals.all():
        DailyPlanMeal.objects.create(
            dailyplan=copy,
            meal=dpm.meal,
           note=dpm.note,
            hour=dpm.hour,
            order=dpm.order,
        )

    messages.success(request, "Daily plan copied successfully")
    return redirect("dailyplan_detail", pk=copy.pk)


@login_required
def remove_meal(request, dailyplan_id, item_id):
    item = get_object_or_404(
        DailyPlanMeal,
        pk=item_id,
        dailyplan_id=dailyplan_id,
    )

    dailyplan_id = item.dailyplan.id
    item.delete()

    return redirect("dailyplan_detail", pk=dailyplan_id)


@require_POST
@login_required
def add_meal_to_dailyplan(request, pk=None):
    dailyplan_id = request.POST.get("dailyplan_id") or pk

    dailyplan = get_object_or_404(
        DailyPlan,
        pk=dailyplan_id,
        created_by=request.user,
    )

    meal_id = request.POST.get("meal_id")
 
    if not meal_id:
        messages.error(request, "Debes seleccionar una meal.")
        return redirect(request.META.get("HTTP_REFERER"))
 
    meal = get_object_or_404(Meal, pk=meal_id)

    hour = request.POST.get("hour") or None
    note = (request.POST.get("note") or "").strip() or None

    DailyPlanMeal.objects.create(
        dailyplan=dailyplan,
        meal=meal,
        hour=hour,
        note=note,
    )

    messages.success(request, "Meal added to daily plan")

    # 🔹 🔹 🔹 redirect depende del estado
    if dailyplan.is_draft:
        return redirect("dailyplan_builder", pk=dailyplan.pk)

    return redirect("dailyplan_edit", pk=dailyplan.pk)


@login_required
def add_meal_flow(request, meal_id):
    """
    Paso intermedio:
    - elegir dailyplan
    - definir hora
    - agregar nota
    """
    meal = get_object_or_404(Meal, pk=meal_id)

    # 🔹 solo MIS dailyplans (drafts por ahora)
    dailyplans = DailyPlan.objects.filter(
        created_by=request.user
    ).order_by("-created_at")

    return render(
        request,
        "notas/dailyplans/add_meal_flow.html",
        {
            "meal": meal,
            "dailyplans": dailyplans,
        },
    )


@login_required
def configure_dailyplan(request, pk):
    dailyplan = get_object_or_404(
        DailyPlan,
        pk=pk,
        created_by=request.user,
    )

    caps = get_capabilities(request.user)

    if request.method == "POST":
        is_public = bool(request.POST.get("is_public"))
        is_forkable = bool(request.POST.get("is_forkable"))
        is_copiable = bool(request.POST.get("is_copiable"))

        # ---- reglas de negocio ----
        if is_public and not caps.can_publish():
            messages.error(request, "You cannot publish this daily plan.")
            return redirect("configure_dailyplan", pk=pk)

        if is_copiable and not caps.can_copy():
            messages.error(request, "Your plan does not allow copies.")
            return redirect("configure_dailyplan", pk=pk)

        dailyplan.is_public = is_public
        dailyplan.is_forkable = is_forkable
        dailyplan.is_copiable = is_copiable

        if dailyplan.is_draft:
            if not dailyplan.dailyplan_meals.exists():
                messages.error(
                    request,
                    "Add at least one meal before finalizing."
                )
                return redirect("dailyplan_detail", pk=pk)

            dailyplan.is_draft = False

        dailyplan.save()
        messages.success(request, "Daily plan saved.")
        return redirect("dailyplan_detail", pk=pk)

    return render(
        request,
        "notas/dailyplans/configure.html",
        {
            "dailyplan": dailyplan,
            "caps": caps,
        }
    )


@login_required
def attach_meal_to_dailyplan(request, dailyplan_id, meal_id):
    dailyplan = get_object_or_404(DailyPlan, id=dailyplan_id)
    meal = get_object_or_404(Meal, id=meal_id)

    if request.method == "POST":
        hour = request.POST.get("hour")
        note = request.POST.get("note")

        DailyPlanMeal.objects.create(
            dailyplan=dailyplan,
            meal=meal,
            hour=hour or None,
            note=note or None
        )

        return redirect("dailyplan_detail", pk=dailyplan.id)

    return render(
        request,
        "notas/dailyplans/attach_meal.html",
        {
            "dailyplan": dailyplan,
            "meal": meal
        }
    )



@login_required
def replace_dailyplan_meal(request, pk):
    dpm = get_object_or_404(
        DailyPlanMeal.objects.select_related("meal", "dailyplan"),
        pk=pk,
        dailyplan__created_by=request.user,
    )

    original_meal = dpm.meal

    # Meal editable (draft nueva)
    replacement_meal = Meal.objects.create(
        name=f"{original_meal.name} (replacement)",
        created_by=request.user,
        is_draft=True,
        original_author=original_meal.created_by,
        forked_from=original_meal,
    )

    context = {
        "dailyplan_meal": dpm,
        "original_meal": original_meal,
        "replacement_meal": replacement_meal,
        "target_kpis": {
            "kcal": original_meal.total_kcal,
            "protein": original_meal.protein,
            "carbs": original_meal.carbs,
            "fat": original_meal.fat,
        },
    }

    return render(
        request,
        "notas/dailyplans/replace_meal.html",
        context,
    )



@require_POST
@login_required
def confirm_replace_meal(request, dpm_id, meal_id):
    dpm = get_object_or_404(
        DailyPlanMeal,
        pk=dpm_id,
        dailyplan__created_by=request.user,
    )

    new_meal = get_object_or_404(Meal, pk=meal_id)

    dpm.meal = new_meal
    dpm.save()

    messages.success(request, "Meal replaced successfully")

    return redirect("dailyplan_detail", pk=dpm.dailyplan.id)




























