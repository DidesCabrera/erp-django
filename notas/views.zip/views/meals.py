from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import HttpResponseForbidden
from django.contrib import messages
from notas.services.capabilities import get_capabilities
from notas.actions.meal_resolvers import resolve_meal_actions
from notas.models import Meal, MealFood, DailyPlan, DailyPlanMeal, Food
from django.urls import reverse
from notas.actions.constants import (
    MEAL_CONTEXT_LIST, 
    MEAL_CONTEXT_DETAIL,
    MEAL_CONTEXT_EDIT,
)
from django.db.models import Sum, F, ExpressionWrapper, FloatField
from notas.services.nutrition import (
    PROTEIN_KCAL_PER_GRAM,
    CARBS_KCAL_PER_GRAM,
    FAT_KCAL_PER_GRAM,
)
from notas.services.viewmodels_builder import build_meal_item


@login_required
def meal_list(request):

    meals = (
        Meal.objects
        .filter(created_by=request.user, is_draft=False)
        .order_by("-created_at")
        .prefetch_related("meal_food_set", "meal_food_set__food")
        .annotate(
            total_kcal_sql=Sum(
                ExpressionWrapper(
                    (F("meal_food_set__quantity") / 100.0) * (
                        F("meal_food_set__food__protein") * PROTEIN_KCAL_PER_GRAM +
                        F("meal_food_set__food__carbs")   * CARBS_KCAL_PER_GRAM +
                        F("meal_food_set__food__fat")     * FAT_KCAL_PER_GRAM
                    ),
                    output_field=FloatField(),
                )
            )
        )
    )

    items = [build_meal_item(m, request.user, MEAL_CONTEXT_LIST) for m in meals]

    return render(
        request,
        "notas/meals/list.html",
        {
            "items": items,
        },
    )


@login_required
def meal_detail(request, pk, dailyplan_id=None):

    meal = (
        Meal.objects
        .prefetch_related("meal_food_set", "meal_food_set__food")
        .get(pk=pk, created_by=request.user)
    )

    caps = get_capabilities(request.user)
    if not caps:
        return HttpResponseForbidden("Unauthorized")

    foods = Food.objects.all()

    item = build_meal_item(meal, request.user, MEAL_CONTEXT_DETAIL)

    navigation = [
        {"label": "My Meals","url": reverse("meal_list")},
        {"label": meal.name,"url": None},
    ]

    if dailyplan_id:
        dailyplan = get_object_or_404(
            DailyPlan,
            pk=dailyplan_id,
            created_by=request.user,
        )
        navigation = [
            {"label": dailyplan.name,"url": reverse("dailyplan_list")},
            {"label": meal.name, "url": None},
        ]

    header = {
        "title": meal.name,
        "subtitle": f"{meal.total_kcal:.0f} kcal",
        "navigation": navigation,
        "actions": resolve_meal_actions(
            meal,
            request.user,
            context={"name": MEAL_CONTEXT_DETAIL},
        ),
    }

    return render(
        request,
        "notas/meals/detail.html",
        {
            "item": item,
            "meal": meal,
            "foods": foods,
            "navigation": navigation,
            "header": header,
        },
    )


@login_required
def meal_edit(request, pk):

    # ⭐ Igual: prefetch MealFood + Food
    meal = (
        Meal.objects
        .prefetch_related("meal_food_set", "meal_food_set__food")
        .get(pk=pk)
    )

    foods = Food.objects.all()
    caps = get_capabilities(request.user)

    if not caps or not caps.can_edit_own_content():
        return HttpResponseForbidden("You cannot edit this meal")

    edit_mf_id = request.GET.get("edit_food")
    edit_mf = None

    if edit_mf_id:
        edit_mf = get_object_or_404(MealFood, pk=edit_mf_id, meal=meal)

    if request.method == "POST":
        if "save_food" in request.POST:
            mf_id = request.POST.get("mealfood_id")

            if mf_id:
                mf = get_object_or_404(MealFood, pk=mf_id, meal=meal)
                mf.quantity = request.POST.get("quantity")
                mf.save()
            else:
                MealFood.objects.create(
                    meal=meal,
                    food_id=request.POST.get("food_id"),
                    quantity=request.POST.get("quantity")
                )

    item = build_meal_item(meal, request.user, MEAL_CONTEXT_EDIT)
    
    navigation = [
        {"label": "Meals","url": reverse("meal_list")},
        {"label": meal.name,"url": None},
    ]

    header = {
        "title": meal.name,
        "subtitle": f"{meal.total_kcal:.0f} kcal",
        "navigation": navigation,
        "actions": resolve_meal_actions(
            meal,
            request.user,
            context={"name": MEAL_CONTEXT_EDIT},
        ),
    }

    

    return render(
        request,
        "notas/meals/edit.html",
        {
            "item": item,
            "meal": meal,
            "foods": foods,
            "header": header,
            "edit_mf": edit_mf,
        }
    )


@login_required
def meal_create(request):
    from_dailyplan = request.GET.get("from_dailyplan")

    if request.method == "POST":
        name = request.POST.get("name")

        if not name:
            messages.error(request, "El nombre es obligatorio")
            return redirect("meal_create")

        meal = Meal.objects.create(
            name=name,
            created_by=request.user,
            is_draft=True
        )

        if from_dailyplan:
            return redirect("attach_meal_to_dailyplan",
                dailyplan_id=from_dailyplan,
                meal_id=meal.id
            )

        return redirect("meal_builder", pk=meal.pk)

    return render(request, "notas/meals/create.html")


@login_required
def meal_rename(request, pk):
    meal = get_object_or_404(Meal, pk=pk)

    # solo permitir renombrar drafts
    if not meal.is_draft:
        return redirect("edit_meal", pk=pk)

    if request.method == "POST":
        name = request.POST.get("name", "").strip()

        if not name:
            messages.error(request, "El nombre no puede estar vacío.")
            return redirect("meal_rename", pk=meal.pk)

        meal.name = name
        meal.save()

        messages.success(request, "Nombre actualizado correctamente.")
        return redirect("meal_builder", pk=pk)

    header = {"title": "Edit meal name"}

    return render(request, "notas/meals/rename.html", {
        "meal": meal,
        "header": header,
    })


@login_required
def meal_builder(request, pk):
    meal = get_object_or_404(Meal, pk=pk)

    item = build_meal_item(meal, request.user, MEAL_CONTEXT_EDIT)

    # por seguridad: solo drafts pueden estar aquí
    if not meal.is_draft:
        return redirect("edit_meal", pk=meal.pk)

    header = {
        "title": "Build meal",
        "back_url": reverse("meal_list"),
    }

    return render(request, "notas/meals/mf_create.html", {
        "item": item,
        "meal": meal,
        "header": header,
    })


@login_required
def configure_meal(request, pk):
    meal = get_object_or_404(
        Meal,
        pk=pk,
        created_by=request.user,
    )

    caps = get_capabilities(request.user)

    if request.method == "POST":
        is_public = bool(request.POST.get("is_public"))
        is_forkable = bool(request.POST.get("is_forkable"))
        is_copiable = bool(request.POST.get("is_copiable"))

        # ---- reglas de negocio ----
        if is_public and not caps.can_publish():
            messages.error(request, "You cannot publish this meal.")
            return redirect("configure_meal", pk=pk)

        if is_copiable and not caps.can_copy():
            messages.error(request, "Your plan does not allow copies.")
            return redirect("configure_meal", pk=pk)

        meal.is_public = is_public
        meal.is_forkable = is_forkable
        meal.is_copiable = is_copiable

        # ---- finalizar draft ----
        if meal.is_draft:
            if not meal.meal_food_set.exists():
                messages.error(
                    request,
                    "Add at least one food before finalizing."
                )
                return redirect("meal_detail", pk=pk)

            meal.is_draft = False

        meal.save()
        messages.success(request, "Meal saved.")
        return redirect("meal_detail", pk=pk)

    return render(
        request,
        "notas/meals/configure.html",
        {
            "meal": meal,
            "caps": caps,
        }
    )


@require_POST
def add_food_to_meal(request, pk):
    meal = get_object_or_404(Meal, pk=pk)

    food_id = request.POST.get("food_id")
    quantity = request.POST.get("quantity")

    if not food_id or not quantity:
        messages.error(request, "Food y cantidad son obligatorios")

        # 👇 si es draft → vuelve al builder
        if meal.is_draft:
            return redirect("meal_builder", pk=meal.pk)
        return redirect("meal_edit", pk=meal.pk)

    food = get_object_or_404(Food, pk=food_id)

    MealFood.objects.create(
        meal=meal,
        food=food,
        quantity=quantity,
    )

    messages.success(request, "Food agregado a la meal")

    # 👇 comportamiento inteligente
    if meal.is_draft:
        return redirect("meal_builder", pk=meal.pk)

    return redirect("meal_edit", pk=meal.pk)


@login_required
@require_POST
def fork_meal(request, meal_id):
    original_meal = get_object_or_404(Meal, id=meal_id)
    profile = request.user.profile

    if not original_meal.is_forkable:
        return HttpResponseForbidden("No puedes forkear esta meal")

    original_author = (
        original_meal.original_author
        if original_meal.original_author
        else original_meal.created_by
    )

    forked_meal = Meal.objects.create(
        name=f"{original_meal.name} (fork)",
        created_by=request.user,
        original_author=original_author,
        forked_from=original_meal,
        is_public=False,
        is_forkable=True,
        is_copiable=False,
        is_draft=False,
    )

    MealFood.objects.bulk_create([
        MealFood(
            meal=forked_meal,
            food=mf.food,
            quantity=mf.quantity
        )
        for mf in original_meal.meal_food_set.all()
    ])

    messages.success(request, "Meal forked successfully")
    return redirect("meal_detail", pk=forked_meal.pk)


@login_required
def replace_meal(request, dailyplan_meal_id, new_meal_id):
    dailyplan_meal = get_object_or_404(DailyPlanMeal, id=dailyplan_meal_id)
    new_meal = get_object_or_404(Meal, id=new_meal_id)

    if dailyplan_meal.dailyplan.created_by != request.user:
        return redirect("dailyplan_detail", dailyplan_meal.dailyplan.id)

    dailyplan_meal.meal = new_meal
    dailyplan_meal.save()

    return redirect("dailyplan_detail", dailyplan_meal.dailyplan.id)


@login_required
@require_POST
def copy_meal(request, pk):
    meal = get_object_or_404(Meal, pk=pk)
    profile = request.user.profile

    if not meal.is_copiable:
        return HttpResponseForbidden("No tienes permiso para copiar esta meal")

    copy = Meal.objects.create(
        name=f"{meal.name} (copy)",
        created_by=request.user,
        is_public=False,
        is_forkable=True,
        is_copiable=False,
        is_draft=False,
    )

    for mf in meal.meal_food_set.all():
        MealFood.objects.create(
            meal=copy,
            food=mf.food,
            quantity=mf.quantity
        )

    messages.success(request, "Meal copiada correctamente")
    return redirect("meal_detail", pk=copy.pk)

