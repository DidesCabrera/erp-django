# notas/actions/dailyplan_actions.py

from django.urls import reverse
from notas.services.permissions import can_fork, can_copy
from .base import link, form


def dailyplan_actions(dailyplan, *, user):
    profile = user.profile
    actions = []

    actions.append(
        link("View", dailyplan.get_absolute_url())
    )

    if dailyplan.created_by == user:
        actions.append(
            link("Settings", dailyplan.get_configure_url())
        )

    if not dailyplan.is_draft and dailyplan.is_forkable and can_fork(profile):
        actions.append(
            form("Fork", reverse("fork_dailyplan", args=[dailyplan.pk]))
        )

    if not dailyplan.is_draft and dailyplan.is_copiable and can_copy(profile):
        actions.append(
            form("Copy", reverse("copy_dailyplan", args=[dailyplan.pk]))
        )

    return actions
