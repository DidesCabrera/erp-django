from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from notas.models import Meal

@login_required
def meal_picker(request):
    meals = Meal.objects.filter(author=request.user).order_by("name")

    context = {
        "meals": meals,
        "picker_mode": True,
    }

    return render(
        request,
        "components/meal_picker.html",
        context
    )
