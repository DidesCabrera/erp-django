# notas/actions/meal_actions.py

from django.urls import reverse
from notas.services.permissions import can_fork, can_copy, can_publish
from .base import link, form


def meal_actions(meal, *, user, context="card"):
    profile = user.profile
    actions = []

    # ---------- VIEW ----------
    actions.append(
        link("View", meal.get_absolute_url())
    )

    # ---------- CONFIGURE ----------
    if meal.created_by == user:
        actions.append(
            link(
                "Settings",
                meal.get_configure_url(),
                enabled=meal.is_draft or not meal.is_public
            )
        )

    # ---------- FORK ----------
    if (
        not meal.is_draft
        and meal.is_forkable
        and can_fork(profile)
    ):
        actions.append(
            form("Fork", reverse("fork_meal", args=[meal.pk]))
        )

    # ---------- COPY ----------
    if (
        not meal.is_draft
        and meal.is_copiable
        and can_copy(profile)
    ):
        actions.append(
            form("Copy", reverse("copy_meal", args=[meal.pk]))
        )

    return actions
